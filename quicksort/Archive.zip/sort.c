#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include "quicksort.h"

void printUsage() {
}
int main(int argc, char **argv) {
    bool i_flag = false, d_flag = false;
    int index, c, num_files;
    char *cvalue = NULL;
    opterr = 0;

    while ((c = getopt(argc, argv, "id")) != -1) {
        switch (c) {
            case 'i':
                i_flag = true, cvalue = optarg;
                break;
            case 'd':
                d_flag = true, cvalue = optarg;
                break;
            case '?':
                if (isprint(optopt)) {
                    fprintf(stderr, "Error: Unknown option `-%c' received.\n", optopt);
                    printUsage();
                } else {
                    printUsage();
                }

                return EXIT_FAILURE;
        }
    }

    for (index = optind; index < argc; index++) {
        num_files++;
    }

    if (!i_flag && !d_flag) {
        printUsage();
        return EXIT_FAILURE;
    }

    if ((i_flag || d_flag) && num_files > 0) {
        printf("Error: No input file specified.\n");
        return EXIT_FAILURE;
    }

    printf(
        "i_flag = %d\n,"
        "d_flag = %d\n"
        "cvalue = %s\n",
        i_flag,
        d_flag,
        cvalue);

    for (index = optind; index < argc; index++)
        printf("Non-option argument %s\n", argv[index]);
    return EXIT_SUCCESS;
}